#define DTC_VERSION "DTC 1.6.0-Android-build"
